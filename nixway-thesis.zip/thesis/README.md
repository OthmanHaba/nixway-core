# Nixway — Graduation Thesis (LaTeX)

A self-hosted Platform-as-a-Service for automated cloud application deployment and infrastructure orchestration.

College of Electronic Technology, Tripoli — Department of Software Engineering.

## Build

This project targets **XeLaTeX** (required for the Arabic abstract via `polyglossia`).

```bash
# one-shot
xelatex -interaction=nonstopmode main.tex
biber main
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode main.tex

# or with latexmk (recommended)
latexmk -xelatex -interaction=nonstopmode main.tex
```

Output: `main.pdf`.

### Required system fonts

- **Inter** (UI text body)
- **JetBrains Mono** (code / monospace)
- **Amiri** (Arabic body)

On macOS:

```bash
brew install --cask font-inter font-jetbrains-mono font-amiri
```

If a font is missing, the preamble falls back to the closest system equivalent automatically — the build does not break.

## Layout

```
thesis/
├── main.tex              # root document, includes everything
├── preamble.tex          # packages, fonts, macros, page layout
├── bibliography.bib      # all references (IEEE-style)
├── chapters/
│   ├── 00_frontmatter.tex
│   ├── 01_introduction.tex
│   ├── 02_literature_review.tex
│   ├── 03_planning.tex
│   ├── 04_analysis.tex
│   ├── 05_design.tex
│   ├── 06_implementation.tex
│   ├── 07_testing.tex
│   └── 08_conclusion.tex
├── appendices/
│   ├── A_schema_reference.tex
│   └── B_adr_log.tex
└── figures/              # all referenced PDFs/PNGs go here
```

## Figures

Every `\includegraphics{figures/fig-X-Y}` references a file that must exist before
the final build. Source diagrams are authored in **Excalidraw** (`*.excalidraw`)
and exported as **PDF** so vector quality is preserved at print scale.

A list of every required figure and its semantic purpose lives in
`figures/MANIFEST.md` (populated as chapters reference each figure).

## Authoring discipline

Three rules carried over from the project's engineering practice:

1. **No claim without code.** Every quantitative statement (table counts,
   migration counts, test counts) must match the running codebase. The
   manifest in §6.1 maps each claim to a verifying file path.
2. **One source of truth per fact.** A fact is defined in exactly one section
   and cross-referenced elsewhere with `\cref{}` — never re-stated.
3. **Cut before adding.** If a sentence does not advance the reader's model
   of the system, delete it.
