# Figure Manifest

This file lists every figure referenced from the LaTeX sources, with a
short description of what each must show. Source diagrams should be
authored in **Excalidraw** (`.excalidraw`) and exported to **PDF** at print
resolution. Save them in this directory with the filenames below.

Until each PDF exists, the LaTeX build will render a labelled placeholder
box at the figure's position — the build never fails on a missing figure.

## Front matter

- `college-logo.pdf` — College of Electronic Technology - Tripoli logo
  for the title page.

## Chapter 3 — Planning

- `03-gantt.pdf` — Gantt chart of the 22-week project schedule. Horizontal
  axis: weeks W1–W22. Seven phase bars plus two cross-cutting tracks
  (Design, Documentation).
- `03-methodology.pdf` — Hybrid Waterfall/Agile process model. Top row:
  seven phase boxes connected left-to-right. Bottom row: a 4-stage loop
  (Plan, Build, Review, Refine) showing the Agile cycle inside each phase.

## Chapter 4 — Analysis

- `04-actors.pdf` — Four stick figures around a "Platform" box: Any User,
  Operator, Tenant Owner/Admin, Developer. Arrows label each actor's
  primary domain.
- `04-dfd-legend.pdf` — DFD notation legend (circle = process, double-line
  = data store, rectangle = external entity, labelled arrow = data flow).
- `04-dfd-l0.pdf` — Level 0 context diagram. Centre: single bubble "P0
  Platform". Around it: four actors + four external systems (GitHub,
  Let's Encrypt, container registries, SMTP relay) + four internal data
  dependencies (Primary DB, In-Memory Store, Object Store, Time-Series Store).
- `04-dfd-l1.pdf` — Level 1. Five process bubbles P1–P5, five data stores
  D1–D5, and a sixth audit-log store D6 floating outside (written by all
  five processes).
- `04-dfd-l2-p1.pdf` — Level 2 P1 Authentication: Sign-Up, Verify Email,
  Log In, Log Out, Reset Password, Send Email (worker), with the email
  queue D-EMAIL-Q.
- `04-dfd-l2-p2.pdf` — Level 2 P2 Server & Cluster: Onboard Server,
  Receive Heartbeats, Create Cluster, Attach Server (Mesh Formation),
  Mesh Repair. Data stores: Servers, Clusters, Cluster Members, WireGuard
  Peers, DNS Records, Mesh Events.
- `04-dfd-l2-p3.pdf` — Level 2 P3 Build & Deploy: Receive Webhook, Build
  Image, Schedule Deploy, Materialise Environment, Pull & Start
  Containers, Health-Gated Cutover, Stream Build & Deploy Logs.
- `04-dfd-l2-p4.pdf` — Level 2 P4 Observability: Collect Metrics, Stream
  Container Logs, Evaluate Autoscaling, Evaluate Alert Rules, Dispatch
  Notification.
- `04-dfd-l2-p5.pdf` — Level 2 P5 Database/Secret/Storage: Provision DB,
  Encrypt Secret, Reveal Secret, Create Volume, Snapshot Volume,
  Schedule & Run Backups.

## Chapter 5 — Design

- `05-erd-clustered.pdf` — ERD organised by domain cluster (5 clusters
  matching the 5 DFD processes), audit log floating outside, junction
  tables drawn in a contrasting colour.
- `05-logical-arch.pdf` — Logical system architecture. Dashed boundary
  around the control plane (API + Worker, sharing PostgreSQL + Redis).
  Web Frontend above. Agents below (outbound arrows only). External
  systems on the right (GitHub, SMTP, registry).
- `05-grpc-stream.pdf` — gRPC bidirectional stream between worker and
  agent. Register one-shot at top; Connect long-lived bidirectional
  stream below. ControlMessage and AgentMessage envelopes labelled with
  variant counts (30 and 29).
- `05-compose.pdf` — Docker Compose topology. Two networks (public +
  internal). 11 services: traefik, api, worker, web, site, migrate,
  postgres, redis, victoria-metrics, vmagent, minio. Annotation: "one
  inbound port on the host (443 via Traefik)".
- `05-seq-deploy.pdf` — Sequence diagram: Deploy from Git push. Six
  lanes: Developer, GitHub, API, Worker, Agent (target), Registry,
  Traefik. Two yellow phase boxes (BUILD, DEPLOY).
- `05-seq-onboard.pdf` — Sequence diagram: Server onboarding & mesh
  attach. Two parts: Trust establishment (SSH probe, install, enrolment,
  persistent stream); Cluster attach (WireGuard KeyGen, peer matrix,
  apply, ping).
- `05-palette.pdf` — Colour palette. Three rows: surfaces & hairlines,
  text, accent & status. Each swatch labelled with hex + CSS variable
  name.
- `05-ui-dashboard-landing.pdf` — Dashboard landing page (post sign-in).
- `05-ui-servers-list.pdf` — Servers list.
- `05-ui-add-server-wizard-1.pdf` — Add-server wizard step 1.
- `05-ui-add-server-wizard-2.pdf` — Add-server wizard step 2.
- `05-ui-server-resources.pdf` — Server-detail Resources tab.
- `05-ui-server-terminal.pdf` — Server-detail Terminal tab.
- `05-ui-cluster-overview.pdf` — Cluster Overview tab.
- `05-ui-cluster-mesh-matrix.pdf` — Cluster Mesh-Health Matrix.
- `05-ui-projects-list.pdf` — Projects list.
- `05-ui-project-detail.pdf` — Project detail page.
- `05-ui-new-app-modal.pdf` — New App modal.
- `05-ui-settings-github.pdf` — Settings → GitHub App Connection.

## Chapter 6 — Implementation

- `06-envelope.pdf` — Envelope encryption diagram. Master key → HKDF
  with team_id → per-team KEK → wraps per-secret DEK → DEK encrypts
  plaintext. Final state: a `secrets` row containing both wrapped_dek
  and ciphertext.
- `06-deploy-states.pdf` — Deployment state machine. States: building →
  scheduling → pulling → starting → health-checking. Branches from
  health-checking: passing → cutover → live; failing → rollback →
  previous-live.

## Chapter 7 — Testing

- `07-pyramid.pdf` — Test pyramid. Base: 87 unit. Middle: 86 integration.
  Top: manual + lab. Annotations: "no automated UI", "no automated load
  test".
