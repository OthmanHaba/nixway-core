#!/usr/bin/env bash
# Generate empty placeholder PDFs so the document compiles end-to-end before
# the real figures are authored. Replace each PDF with the real export
# from Excalidraw / Figma as you produce it.
#
# Requires ImageMagick OR Ghostscript OR sips (macOS).

set -euo pipefail

cd "$(dirname "$0")"

stubs=(
  03-gantt 03-methodology
  04-actors 04-dfd-legend 04-dfd-l0 04-dfd-l1
  04-dfd-l2-p1 04-dfd-l2-p2 04-dfd-l2-p3 04-dfd-l2-p4 04-dfd-l2-p5
  05-erd-clustered 05-logical-arch 05-grpc-stream 05-compose
  05-seq-deploy 05-seq-onboard 05-palette
  05-ui-dashboard-landing 05-ui-servers-list
  05-ui-add-server-wizard-1 05-ui-add-server-wizard-2
  05-ui-server-resources 05-ui-server-terminal
  05-ui-cluster-overview 05-ui-cluster-mesh-matrix
  05-ui-projects-list 05-ui-project-detail
  05-ui-new-app-modal 05-ui-settings-github
  06-envelope 06-deploy-states
  07-pyramid
  college-logo
)

# Strategy: write a tiny one-page PDF with the figure name as visible text.
# Uses the simplest possible raw-PDF stream so no external tools are required.
write_stub_pdf() {
  local name="$1"
  local file="${name}.pdf"
  [ -f "$file" ] && return 0

  python3 - <<PY
import struct
name = "${name}"
text = f"PLACEHOLDER: {name} -- replace with the real export"
# Minimal valid PDF 1.4
content = f"BT /F1 12 Tf 50 750 Td ({text}) Tj ET".encode()
objects = []
def add(obj_bytes):
    objects.append(obj_bytes); return len(objects)
catalog = add(b"<< /Type /Catalog /Pages 2 0 R >>")
pages   = add(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
page    = add(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>")
stream  = add(b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content + b"\nendstream")
font    = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
out = b"%PDF-1.4\n"
offsets = [0]
for i, body in enumerate(objects, start=1):
    offsets.append(len(out))
    out += f"{i} 0 obj\n".encode() + body + b"\nendobj\n"
xref = len(out)
out += f"xref\n0 {len(objects)+1}\n".encode()
out += b"0000000000 65535 f \n"
for off in offsets[1:]:
    out += f"{off:010d} 00000 n \n".encode()
out += f"trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
open("${file}", "wb").write(out)
PY
}

for s in "${stubs[@]}"; do
  write_stub_pdf "$s"
done

echo "Stub PDFs written to $(pwd)"
ls -1 *.pdf | wc -l | xargs printf "%s PDFs present\n"
